
    <footer class="footer">
        <div class="footer_content">
            <div class="item"  >
                <div class="logo">
                    <a href="#"><img src="../fashion/img/imgg/logos.png" alt="logo" /></a>
                </div>

                <div class="address">
                    <p class="contact_address">Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>

                    </div>
                    
                    <div class="call_maill">
                    <ul>
                        <li> <p class="call_me">Call Us : <a href="#callme">+ 33 44 666 5556</a></p></li>
                        <li> <p class="mail_id">Email : <a href="#callme">fffffff@gmail.com</a></p></li>
                    </ul>
                </div>

                <!-- <div class="social_icons">
                    <ul>
                        <li> 
                            <a href="#facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a> 
                        </li>
                        <li> 
                            <a href="#instagram"><i class="fa fa-instagram" aria-hidden="true"></i></a> 
                        </li>
                        <li> 
                            <a href="#whatsapp"><i class="fa fa-whatsapp" aria-hidden="true"></i></a> 
                        </li>
                        <li> 
                            <a href="#youtube   "><i class="fa fa-youtube" aria-hidden="true"></i></a> 
                        </li>
                    </ul>
                </div> -->
            </div>

            <div class="link_item item " id="item">
            <h5>Information</h5>
                <ul>   
                    
                    <li><a href="#">About us</a></li>
                    <li><a href="#">FAQ</a></li>
                    <li><a href="#">Delivery Information</a></li>
                    <li><a href="#">Contact us</a></li>
                </ul>

                
            </div>

            <div class="link_item item"  id="item">
            <h5>Account</h5>
                <ul>   
                    
                    <li><a href="#">My account</a></li>
                    <li><a href="#">Order History</a></li>
                    <li><a href="#">Wish List</a></li>
                    <li><a href="#">Specials</a></li>
                </ul>

            </div>

            <div class="item link_item"  id="item">
                <ul>   
                    <h5>Services</h5>
                    <li><a href="#">Discount Returns</a></li>
                    <li><a href="#">Our Policy</a></li>
                    <li><a href="#">Customer Service</a></li>
                    <li><a href="#">Terms & condition</a></li>
                </ul>

            </div>

            <div class="item link_item"  id="item">
                <ul>   
                    <h5>Information</h5>
                    <li><a href="#">About Us</a></li>
                    <li><a href="#">Contact Us</a></li>
                    <li><a href="#">Careers</a></li>
                    <li><a href="#">About Us</a></li>
                </ul>

            </div>
            <div class="footer_search d-none">
            <form action="#">
                <ul>
                  <li>
                    <input  class="form-control me-2 input_search" type="search" placeholder="Search for products"
                      aria-label="Search"
                    />
                  </li>
      
                    <li><button type="submit" class=""> 
                      <i class="fa fa-search"></i></button>
                    </li>
      
                </ul>
              </form>
        </div>
        </div>

        <hr>

        <p id="reserved">@</p>
    </footer>




    
   
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" ></script>
        <!-- jquery cdn link -->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" ></script>
     <!-- Swiper JS -->
     <script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
<script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>
<script src="js/fashion.js"></script>
<script src="js/product_slider.js "></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</body>
</html>